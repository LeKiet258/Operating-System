#include "syscall.h"

int main() {
	PrintString("\n1. Gioi thieu ve nhom:");
	PrintString("\n\t- Le Kiet (19120554)");
	PrintString("\n\t- Ho Huu Ngoc (19120602)");
	PrintString("\n\t- Hoang Manh Khiem (19120543)");
	PrintString("\n\t- Nguyen Phat Minh (19120586)\n");
	
	PrintString("\n2. Chuong trinh sort: dung thuat toan Bubble Sort de sap xep mang n so nguyen theo thu tu tang dan hoac giam dan, n (n <= 100) la so nguyen do nguoi dung nhap vao\n");
	PrintString("\n3. Chuong trinh ascii: In bang ma ASCII ra man hinh.\n");

	return 0;
}
