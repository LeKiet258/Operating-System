#include "syscall.h"

int main()
{
	PrintChar(ReadChar());
	//PrintChar('9');
	return 0;
}

