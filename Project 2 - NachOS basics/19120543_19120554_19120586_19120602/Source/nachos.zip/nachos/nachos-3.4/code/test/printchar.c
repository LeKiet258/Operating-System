#include "syscall.h"

int main()
{
	PrintChar('A');
	return 0;
}

